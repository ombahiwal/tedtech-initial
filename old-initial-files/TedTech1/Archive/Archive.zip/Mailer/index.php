<html>
<form method="post" name="contact_form"
action="sendmail.php">
    To:
    <input type="text" name="to">
    subject:
    <input type="text" name="subject">
    body:
    <textarea name="body"></textarea>
    <input type="submit" name="send">
</form>



</html>
